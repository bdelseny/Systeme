void display (void);

extern char message[];

