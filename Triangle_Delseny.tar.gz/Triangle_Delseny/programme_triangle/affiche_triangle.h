#ifndef ORIGINE_Y
#define ORIGINE_Y 200		   /* Origine du tableau en X,Y */
#endif

#define ORIGINE_X 10
#define RATIO_DELTA_X 0.6	   /* Largeur caractere / taille police */
#define RATIO_DELTA_Y (1.0 + .25)  /* Espacement vertical : 1 + x% */

void postscript_triangle (unsigned int taille_police);

//#define TRACE_BOITE

