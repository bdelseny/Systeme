extern unsigned int maximum_pascal;

int creer_boite(int argc, char *argv[], int call);

void boite_chiffre (unsigned int taille_police, char *sortie,
		    unsigned int x, unsigned int y,
		    unsigned int delta_x, unsigned int delta_y,
		    unsigned int valeur, unsigned int nb_car);
