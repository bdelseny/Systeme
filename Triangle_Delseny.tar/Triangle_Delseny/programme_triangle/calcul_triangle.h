#define MAX_LIGNES 40 

extern unsigned int taille_triangle;
void triangle_pascal (void);
unsigned int pascal (unsigned int l, unsigned int c);
