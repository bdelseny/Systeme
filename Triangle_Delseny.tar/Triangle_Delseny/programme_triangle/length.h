#define MAX_INT_LENGTH 11          /* 32 bits : maxi 4G --> 10 digits */
#define MAX_FILE_NAME_LENGTH 400   /* Full path name max lentgh */
